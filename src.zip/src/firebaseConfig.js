// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";

// Your Firebase project configuration
const firebaseConfig = {
  apiKey: "AIzaSyDYfsLQA1RSaAREvUmWvHr12TdX7MtVokY",
  authDomain: "company-module-f5389.firebaseapp.com",
  projectId: "company-module-f5389",
  storageBucket: "company-module-f5389.firebasestorage.app",
  messagingSenderId: "446072673762",
  appId: "1:446072673762:web:c34e341c155042f87855bb"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
